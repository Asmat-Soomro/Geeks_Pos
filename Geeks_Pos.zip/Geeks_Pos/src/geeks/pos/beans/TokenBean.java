/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package geeks.pos.beans;

import java.io.Serializable;

/**
 *
 * @author Asmat
 */
public class TokenBean extends Bean implements Serializable{
    private Integer tokenId;
    private String tokenName;
    private Double tokenDiscount;
    
    public Integer getTokenId() {
        return tokenId;
    }

    public void setTokenId(Integer tokenId) {
        this.tokenId = tokenId;
    }

    public String getTokenName() {
        return tokenName;
    }

    public void setTokenName(String tokenName) {
        this.tokenName = tokenName;
    }
    
    public Double getTokenDiscount() {
        return tokenDiscount;
    }

    public void setTokenDiscount(Double tokenDiscount) {
        this.tokenDiscount = tokenDiscount;
    }
    
}
