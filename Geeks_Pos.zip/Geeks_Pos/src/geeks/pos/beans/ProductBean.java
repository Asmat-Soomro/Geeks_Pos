/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package geeks.pos.beans;

import java.io.Serializable;
import java.sql.Timestamp;

/**
 *
 * @author Asmat
 */
public class ProductBean extends Bean implements Serializable{
    private Integer productId;
    private String productName;
    private String isbn;
    private Timestamp manufacturingDate;
    private Timestamp expiryDate;
    private String barCode;
    private Double retailPrice;
    private Double salePrice;
    private CategoryBean categoryId;
    private CompanyBean company;
    private Integer stock;
    private String warranty;
    private SizeBean sizeId;
    private String comments;
    
    public Integer getProductId() {
        return productId;
    }

    public void setProductId(Integer productId) {
        this.productId = productId;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public Timestamp getManufacturingDate() {
        return manufacturingDate;
    }

    public void setManufacturingDate(Timestamp manufacturingDate) {
        this.manufacturingDate = manufacturingDate;
    }

    public Timestamp getExpiryDate() {
        return expiryDate;
    }

    public void setExpiryDate(Timestamp expiryDate) {
        this.expiryDate = expiryDate;
    }

    public String getBarCode() {
        return barCode;
    }

    public void setBarCode(String barCode) {
        this.barCode = barCode;
    }

    public Double getRetailPrice() {
        return retailPrice;
    }

    public void setRetailPrice(Double retailPrice) {
        this.retailPrice = retailPrice;
    }

    public Double getSalePrice() {
        return salePrice;
    }

    public void setSalePrice(Double salePrice) {
        this.salePrice = salePrice;
    }

    public CategoryBean getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(CategoryBean categoryId) {
        this.categoryId = categoryId;
    }

    public CompanyBean getCompany() {
        return company;
    }

    public void setCompany(CompanyBean company) {
        this.company = company;
    }

    public Integer getStock() {
        return stock;
    }

    public void setStock(Integer stock) {
        this.stock = stock;
    }

    public String getWarranty() {
        return warranty;
    }

    public void setWarranty(String warranty) {
        this.warranty = warranty;
    }

    public SizeBean getSizeId() {
        return sizeId;
    }

    public void setSizeId(SizeBean sizeId) {
        this.sizeId = sizeId;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }
    
}