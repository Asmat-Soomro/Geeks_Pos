/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package geeks.pos.beans;

import java.io.Serializable;

/**
 *
 * @author Asmat
 */
public class SaleDetailBean extends Bean implements Serializable{
    private Integer saleDetailId;
    private ProductBean productId;
    private String productQuantity;
    private Double price;
    private SaleBean saleId;

    public Integer getSaleDetailId() {
        return saleDetailId;
    }

    public void setSaleDetailId(Integer saleDetailId) {
        this.saleDetailId = saleDetailId;
    }

    public ProductBean getProductId() {
        return productId;
    }

    public void setProductId(ProductBean productId) {
        this.productId = productId;
    }


    public String getProductQuantity() {
        return productQuantity;
    }

    public void setProductQuantity(String productQuantity) {
        this.productQuantity = productQuantity;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public SaleBean getSaleId() {
        return saleId;
    }

    public void setSaleId(SaleBean saleId) {
        this.saleId = saleId;
    }
}
