package geeks.pos.connection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class SqlConnection {
    private SqlConnection() {}
    static Connection con= null;
    public static Connection makeConnection() 
    {
	if(con==null) {
            try {
                    Class.forName("com.mysql.jdbc.Driver");
                    con= DriverManager.getConnection("jdbc:mysql://localhost:3306/geeks_pos_db","root","");
                }
            catch (ClassNotFoundException | SQLException e) {
            System.out.println(e.getMessage());
                JOptionPane.showMessageDialog(null, "Xampp Is Not Open!");
                    }
		}
	return con;
    }
}