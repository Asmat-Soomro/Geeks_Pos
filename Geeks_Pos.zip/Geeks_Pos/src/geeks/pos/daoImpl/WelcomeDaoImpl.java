/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package geeks.pos.daoImpl;

import geeks.pos.connection.SqlConnection;
import geeks.pos.dao.WelcomeDao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Asmat
 */
public class WelcomeDaoImpl implements WelcomeDao{
    private static final Connection con = SqlConnection.makeConnection();
    private static PreparedStatement pst ;
    private static ResultSet rst ;
    @Override
    public int getMainId(String username) {
        
        int mainId=0;
            try {
                pst=con.prepareStatement("select user_id from user where user_name =?");
                pst.setString(1, username);
                rst=pst.executeQuery();
                while(rst.next())
                {
                   mainId = rst.getInt("user_id");
                }
            } catch (SQLException ex) {
                Logger.getLogger(UserDaoImpl.class.getName()).log(Level.SEVERE, null, ex);
            }
        return mainId;
    }
    
}
