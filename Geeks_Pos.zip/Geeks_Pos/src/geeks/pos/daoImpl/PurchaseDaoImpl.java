/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package geeks.pos.daoImpl;

import geeks.pos.beans.PurchaseBean;
import geeks.pos.connection.SqlConnection;
import geeks.pos.dao.PurchaseDao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Asmat
 */
public class PurchaseDaoImpl implements PurchaseDao{
    private static final Connection con = SqlConnection.makeConnection();
    private static PreparedStatement pst ;
    private static ResultSet rst ; 

    @Override
    public int addPurchase(PurchaseBean purchaseBean) {
        int i = 0;
        try {
            pst=con.prepareStatement("insert into purchase(purchase_date,company_id,purchase_number,dicount_type,value,comments,created_by,created_date,modified_by,modified_date)values(?,?,?,?,?,?,?,?,?,?)");
            pst.setTimestamp(1,purchaseBean.getPurchaseDate());
            pst.setInt(2, purchaseBean.getCompanyId().getCompanyId());
            pst.setInt(3, purchaseBean.getPurchaseNumber());
            pst.setString(4, purchaseBean.getDiscountType());
            pst.setString(5, purchaseBean.getValue());
            pst.setString(6, purchaseBean.getComments());
            pst.setInt(7,purchaseBean.getCreatedBy());
            pst.setTimestamp(8,purchaseBean.getCreatedDate());
            pst.setInt(9,purchaseBean.getModifiedBy());
            pst.setTimestamp(10,purchaseBean.getModifiedDate());
            i = pst.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(PurchaseDaoImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
    return i;
    }

    @Override
    public int updatePurchase(PurchaseBean purchaseBean) {
        int i = 0;
        try {
            pst=con.prepareStatement("update purchaseset purchase_date=?,company_id=?,purchase_number=?,dicount_type=?,value=?,comments=?,modified_by=?,modified_date=? where purchase_id = ?");
            pst.setTimestamp(1,purchaseBean.getPurchaseDate());
            pst.setInt(2, purchaseBean.getCompanyId().getCompanyId());
            pst.setInt(3, purchaseBean.getPurchaseNumber());
            pst.setString(4, purchaseBean.getDiscountType());
            pst.setString(5, purchaseBean.getValue());
            pst.setString(6, purchaseBean.getComments());
            pst.setInt(7,purchaseBean.getModifiedBy());
            pst.setTimestamp(8,purchaseBean.getModifiedDate());
            pst.setInt(9, purchaseBean.getPurchaseId());
            i = pst.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(PurchaseDaoImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
    return i;
    }

    @Override
    public int deletePurchase(PurchaseBean purchaseBean) {
        int i = 0;
        try {    
            pst=con.prepareStatement("update purchase set active=? where purchase_id =? ");
            pst.setInt(1, 0);
            pst.setInt(2, purchaseBean.getPurchaseId());
            i = pst.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(PurchaseDaoImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
    return i;
    }

    @Override
    public List<PurchaseBean> getAllPurchases() {
        List <PurchaseBean> list = new ArrayList();
        try {
            pst=con.prepareStatement("select * from purchase where active = ?");
            pst.setInt(1, 1);
            rst = pst.executeQuery();
            while(rst.next())
            {
              PurchaseBean purchaseBean = new PurchaseBean();
              CompanyDaoImpl companyDaoImpl = new CompanyDaoImpl();
              purchaseBean.setPurchaseId(rst.getInt("purchase_id"));
              purchaseBean.setPurchaseDate(rst.getTimestamp("purchase_date"));
              purchaseBean.setCompanyId(companyDaoImpl.getCompanyById(rst.getInt("company_id")));
              purchaseBean.setPurchaseNumber(rst.getInt("purchase_number"));
              purchaseBean.setDiscountType(rst.getString("discount_type"));
              purchaseBean.setValue(rst.getString("value"));
              purchaseBean.setComments(rst.getString("comments"));
              purchaseBean.setCreatedBy(rst.getInt("created_by"));
              purchaseBean.setCreatedDate(rst.getTimestamp("created_date"));
              purchaseBean.setModifiedBy(rst.getInt("modified_by"));
              purchaseBean.setModifiedDate(rst.getTimestamp("modified_date"));
              list.add(purchaseBean);
            }
        } catch (SQLException ex) {
            Logger.getLogger(PurchaseDaoImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
        return list;
    }

    @Override
    public PurchaseBean getPurchaseById(Integer purchaseId) {
        PurchaseBean purchaseBean = new PurchaseBean();
        CompanyDaoImpl companyDaoImpl = new CompanyDaoImpl();
        try {    
            pst=con.prepareStatement("select * from purchase where purchase_id = ?");
            pst.setInt(1, purchaseId);
            rst=pst.executeQuery();
            while(rst.next())
            {
              purchaseBean.setPurchaseId(rst.getInt("purchase_id"));
              purchaseBean.setPurchaseDate(rst.getTimestamp("purchase_date"));
              purchaseBean.setCompanyId(companyDaoImpl.getCompanyById(rst.getInt("company_id")));
              purchaseBean.setPurchaseNumber(rst.getInt("purchase_number"));
              purchaseBean.setDiscountType(rst.getString("discount_type"));
              purchaseBean.setValue(rst.getString("value"));
              purchaseBean.setComments(rst.getString("comments"));
              purchaseBean.setCreatedBy(rst.getInt("created_by"));
              purchaseBean.setCreatedDate(rst.getTimestamp("created_date"));
              purchaseBean.setModifiedBy(rst.getInt("modified_by"));
              purchaseBean.setModifiedDate(rst.getTimestamp("modified_date"));
            }
        } catch (SQLException ex) {
            Logger.getLogger(PurchaseDaoImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
        return purchaseBean;
    }
}
