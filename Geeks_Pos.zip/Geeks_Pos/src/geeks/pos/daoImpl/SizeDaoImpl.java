/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package geeks.pos.daoImpl;

import geeks.pos.beans.SizeBean;
import geeks.pos.connection.SqlConnection;
import geeks.pos.dao.SizeDao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Asmat
 */
public class SizeDaoImpl implements SizeDao{
    private static final Connection con = SqlConnection.makeConnection();
    private static PreparedStatement pst ;
    private static ResultSet rst ;
    @Override
    public int addSize(SizeBean sizeBean) {
        int i = 0;
        try {
            pst=con.prepareStatement("insert into size(size,pack,created_by,created_date,modified_by,modified_date)values(?,?,?,?,?,?)");
            pst.setString(1,sizeBean.getSize());
            pst.setString(2,sizeBean.getPack());
            pst.setInt(3,sizeBean.getCreatedBy());
            pst.setTimestamp(4,sizeBean.getCreatedDate());
            pst.setInt(5,sizeBean.getModifiedBy());
            pst.setTimestamp(6,sizeBean.getModifiedDate());
            i = pst.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(SizeDaoImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    return i;
    }

    @Override
    public int updateSize(SizeBean sizeBean) {
        int i = 0;
        try {
            pst=con.prepareStatement("update size set size=?, pack=?,  modified_by=?, modified_date=? where size_id =?");
            pst.setString(1,sizeBean.getSize());
            pst.setString(2,sizeBean.getPack());
            pst.setInt(3,sizeBean.getModifiedBy());
            pst.setTimestamp(4,sizeBean.getModifiedDate());
            pst.setInt(5, sizeBean.getSizeId());
            i = pst.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(SizeDaoImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    return i;
    }

    @Override
    public int deleteSize(SizeBean sizeBean) {
       int i = 0;
        try {    
            pst=con.prepareStatement("update size set active=? where size_id =? ");
            pst.setInt(1, 0);
            pst.setInt(2, sizeBean.getSizeId());
            i = pst.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(SizeDaoImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
    return i;
    }

    @Override
    public ResultSet getAllSizes() {
        try {
            pst=con.prepareStatement("select * from size where active = ?");
            pst.setInt(1, 1);
            rst = pst.executeQuery();
        } catch (SQLException ex) {
            Logger.getLogger(SizeDaoImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
        return rst;
    }

    @Override
    public SizeBean getSizeById(Integer sizeId) {
        SizeBean sizeBean = new SizeBean();
        try {    
            pst=con.prepareStatement("select * from size where size_id = ?");
            pst.setInt(1, sizeId);
            rst=pst.executeQuery();
            while(rst.next())
            {
              sizeBean.setSizeId(rst.getInt("size_id"));
              sizeBean.setSize(rst.getString("size"));
              sizeBean.setPack(rst.getString("pack"));
              sizeBean.setCreatedBy(rst.getInt("created_by"));
              sizeBean.setCreatedDate(rst.getTimestamp("created_date"));
              sizeBean.setModifiedBy(rst.getInt("modified_by"));
              sizeBean.setModifiedDate(rst.getTimestamp("modified_date"));
              
            }
        } catch (SQLException ex) {
            Logger.getLogger(SizeDaoImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
        return sizeBean;
    }
    public Integer getSizeIdByCreatedDate(Timestamp createdDate)
    {
        Integer sizeId = 0;
        try {
            pst=con.prepareStatement("select size_id from size where created_date = ?");
            pst.setTimestamp(1, createdDate);
            rst=pst.executeQuery();
            while(rst.next())
            {
                sizeId = rst.getInt("size_id");
            }
                } catch (SQLException ex) {
            Logger.getLogger(SizeDaoImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
        return sizeId;
    }

    public Integer getSizeIdBySizeName(String size) {
        Integer sizeId = 0;
        try {
            pst=con.prepareStatement("select size_id from size where size = ?");
            pst.setString(1, size);
            rst=pst.executeQuery();
            while(rst.next())
            {
                sizeId = rst.getInt("size_id");
            }
        } catch (SQLException ex) {
            Logger.getLogger(SizeDaoImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
        return sizeId;
    }

    
}
