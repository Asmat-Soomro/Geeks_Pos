/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package geeks.pos.daoImpl;

import geeks.pos.beans.SaleBean;
import geeks.pos.connection.SqlConnection;
import geeks.pos.dao.SaleDao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Asmat
 */
public class SaleDaoImpl implements SaleDao{
    private static final Connection con = SqlConnection.makeConnection();
    private static PreparedStatement pst ;
    private static ResultSet rst ;
    @Override
    public int addSale(SaleBean saleBean) {
        int i = 0;
        try {
            pst=con.prepareStatement("insert into sale(sale_date,customer_id,employee_id,sale_number,comments,created_by,created_date,modified_by,modified_date)values(?,?,?,?,?,?,?,?,?)");
            pst.setTimestamp(1,saleBean.getSaleDate());
//--------->    pst.setInt(2, i);
//--------->    pst.setInt(3, i);
            pst.setInt(4, saleBean.getSaleNumber());
            pst.setString(5, saleBean.getComments());
            pst.setInt(6,saleBean.getCreatedBy());
            pst.setTimestamp(7,saleBean.getCreatedDate());
            pst.setInt(8,saleBean.getModifiedBy());
            pst.setTimestamp(9,saleBean.getModifiedDate());
            i = pst.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(SaleDaoImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    return i;
    }

    @Override
    public int updateSale(SaleBean saleBean) {
        int i = 0;
        try {
            pst=con.prepareStatement("update sale set sale_date=?,customer_id=?,employee_id=?,sale_number=?,comments=?,modified_by=?,modified_date=? where sale_id = ?");
            pst.setTimestamp(1,saleBean.getSaleDate());
            pst.setInt(2, i);
            pst.setInt(3, i);
            pst.setInt(4, saleBean.getSaleNumber());
            pst.setString(5, saleBean.getComments());
            pst.setInt(6,saleBean.getModifiedBy());
            pst.setTimestamp(7,saleBean.getModifiedDate());
            pst.setInt(8, saleBean.getSaleId());
            i = pst.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(SaleDaoImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    return i;
    }

    @Override
    public int deleteSale(SaleBean saleBean) {
        int i = 0;
        try {    
            pst=con.prepareStatement("update sale set active=? where sale_id =? ");
            pst.setInt(1, 0);
            pst.setInt(2, saleBean.getSaleId());
            i = pst.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(SaleDaoImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
    return i;
    }

    @Override
    public List<SaleBean> getAllSales() {
        List <SaleBean> list = new ArrayList();
        try {
            pst=con.prepareStatement("select * from sale where active = ?");
            pst.setInt(1, 1);
            rst = pst.executeQuery();
            while(rst.next())
            {
              SaleBean saleBean = new SaleBean();
              saleBean.setSaleId(rst.getInt("sale_id"));
              saleBean.setSaleDate(rst.getTimestamp("sale_date"));
              
              
              saleBean.setSaleNumber(rst.getInt("sale_number"));
              saleBean.setComments(rst.getString("comments"));
              saleBean.setCreatedBy(rst.getInt("created_by"));
              saleBean.setCreatedDate(rst.getTimestamp("created_date"));
              saleBean.setModifiedBy(rst.getInt("modified_by"));
              saleBean.setModifiedDate(rst.getTimestamp("modified_date"));
              list.add(saleBean);
            }
        } catch (SQLException ex) {
            Logger.getLogger(SaleDaoImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
        return list;
    }

    @Override
    public SaleBean getSaleById(Integer saleId) {
        SaleBean saleBean = new SaleBean();
        try {    
            pst=con.prepareStatement("select * from sale where sale_id = ?");
            pst.setInt(1, saleId);
            rst=pst.executeQuery();
            while(rst.next())
            {
              saleBean.setSaleId(rst.getInt("sale_id"));
              saleBean.setSaleDate(rst.getTimestamp("sale_date"));
              
              
              saleBean.setSaleNumber(rst.getInt("sale_number"));
              saleBean.setComments(rst.getString("comments"));
              saleBean.setCreatedBy(rst.getInt("created_by"));
              saleBean.setCreatedDate(rst.getTimestamp("created_date"));
              saleBean.setModifiedBy(rst.getInt("modified_by"));
              saleBean.setModifiedDate(rst.getTimestamp("modified_date"));
              
            }
        } catch (SQLException ex) {
            Logger.getLogger(SaleDaoImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
        return saleBean;
    }
    
}
