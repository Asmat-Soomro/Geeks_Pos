/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package geeks.pos.daoImpl;

import geeks.pos.beans.CategoryBean;
import geeks.pos.connection.SqlConnection;
import geeks.pos.dao.CategoryDao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Asmat
 */
public class CategoryDaoImpl implements CategoryDao{

    private static final Connection con = SqlConnection.makeConnection();
    private static PreparedStatement pst ;
    private static ResultSet rst ;
    @Override
    public int addCategory(CategoryBean categoryBean) {
        int i = 0;
        try {
            pst=con.prepareStatement("insert into category(parent_category,category_name,created_by,created_date,modified_by,modified_date)values(?,?,?,?,?,?)");
            if(categoryBean.getParentCategory() != null)
                pst.setInt(1,categoryBean.getParentCategory().getCategoryId());
            else
            pst.setString(1,null);
            pst.setString(2,categoryBean.getCategoryName());
            pst.setInt(3, categoryBean.getCreatedBy());
            pst.setTimestamp(4, categoryBean.getCreatedDate());
            pst.setInt(5, categoryBean.getModifiedBy());
            pst.setTimestamp(6, categoryBean.getModifiedDate());
            i = pst.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(CategoryDaoImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    return i;
    }

    @Override
    public int updateCategory(CategoryBean categoryBean) {
        int i =0;
        try {
            pst=con.prepareStatement("update category set parent_category=?, category_name=?, modified_by=?, modified_date=? where category_id =?");
            if(categoryBean.getParentCategory() != null)
                pst.setInt(1,categoryBean.getParentCategory().getCategoryId());
            else
            pst.setString(1,null);
            pst.setString(2, categoryBean.getCategoryName());
            pst.setInt(3, categoryBean.getModifiedBy());
            pst.setTimestamp(4, categoryBean.getModifiedDate());
            pst.setInt(5, categoryBean.getCategoryId());
            i = pst.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(CategoryDaoImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
    return i;
    }

    @Override
    public int deleteCategory(CategoryBean categoryBean) {
        int i = 0;
        try {    
            pst=con.prepareStatement("update category set active=? where category_id =? ");
            pst.setInt(1, 0);
            pst.setInt(2, categoryBean.getCategoryId());
            i = pst.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(CategoryDaoImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
    return i;
    }

    @Override
    public ResultSet getAllCategories() {
        try {
            pst=con.prepareStatement("select * from category where active = ?");
            pst.setInt(1, 1);
            rst = pst.executeQuery();
            } catch (SQLException ex) {
            Logger.getLogger(CategoryDaoImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
        return rst;
    }

    @Override
    public CategoryBean getCategoryById(Integer CategoryId) {
        CategoryBean categoryBean = null;
        try {    
            pst=con.prepareStatement("select * from category where category_id = ? and active = 1");
            pst.setInt(1, CategoryId);
            rst=pst.executeQuery();
            while(rst.next())
            {
                categoryBean = new CategoryBean();
                categoryBean.setCategoryId(CategoryId);
                categoryBean.setCategoryName(rst.getString("category_name"));
                if(getCategoryById(rst.getInt("parent_category"))==null)
                    categoryBean.setParentCategory(null);
                else{
                    categoryBean.setParentCategory(getCategoryById(rst.getInt("parent_category")));
                    System.out.println(rst.getInt("created_by"));
                    categoryBean.setCreatedBy(rst.getInt("created_by"));
                    categoryBean.setCreatedDate(rst.getTimestamp("created_date"));
                    categoryBean.setModifiedBy(rst.getInt("modified_by"));
                    categoryBean.setModifiedDate(rst.getTimestamp("modified_date"));
                }
            }
        } catch (SQLException ex) {
            Logger.getLogger(CategoryDaoImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
        return categoryBean;
    }   
    
    public List<CategoryBean> getAllParentCategories(){
        List<CategoryBean> categories  = new ArrayList<>();
        CategoryBean parent = null;
        try{
        pst = con.prepareStatement("Select * from category where active=? and parent_category is null");
        pst.setInt(1, 1);
        rst = pst.executeQuery();
        while(rst.next()){
            parent = new CategoryBean();
            parent.setCategoryName(rst.getString("category_name"));
            categories.add(parent);
        }
        }catch(SQLException ex){}
        
        return categories;
    }
    public Integer getCategoryId(String CategoryName) {
        Integer categoryId = null;
        try {    
            pst=con.prepareStatement("select category_id from category where category_name = ? and active = ?");
            pst.setString(1, CategoryName);
            pst.setInt(2, 1);
            rst=pst.executeQuery();
            while(rst.next())
            {
                categoryId = rst.getInt("category_id");
            }
        } catch (SQLException ex) {
            Logger.getLogger(CategoryDaoImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
        return categoryId;
    }
    
}