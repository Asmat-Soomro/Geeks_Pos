/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package geeks.pos.daoImpl;

import geeks.pos.beans.TokenBean;
import geeks.pos.connection.SqlConnection;
import geeks.pos.dao.TokenDao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Asmat
 */
public class TokenDaoImpl implements TokenDao{
    private static final Connection con = SqlConnection.makeConnection();
    private static PreparedStatement pst ;
    private static ResultSet rst ;
    @Override
    public int addToken(TokenBean tokenBean) {
         int i = 0;
        try {
            pst=con.prepareStatement("insert into token(token_name,token_discount,created_by,created_date,modified_by,modified_date)values(?,?,?,?,?,?)");
            pst.setString(1, tokenBean.getTokenName());
            pst.setDouble(2,tokenBean.getTokenDiscount());
            pst.setInt(3,tokenBean.getCreatedBy());
            pst.setTimestamp(4,tokenBean.getCreatedDate());
            pst.setInt(5,tokenBean.getModifiedBy());
            pst.setTimestamp(6,tokenBean.getModifiedDate());
            i = pst.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(TokenDaoImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    return i;
    }

    @Override
    public int updateToken(TokenBean tokenBean) {
       int i = 0;
        try {
            pst=con.prepareStatement("update token set token_name=?, token_discount=?,  modified_by=?, modified_date=? where token_id =?");
            pst.setString(1, tokenBean.getTokenName());
            pst.setDouble(2,tokenBean.getTokenDiscount());
            pst.setInt(3,tokenBean.getModifiedBy());
            pst.setTimestamp(4,tokenBean.getModifiedDate());
            pst.setInt(5, tokenBean.getTokenId());
            i = pst.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(TokenDaoImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    return i;
    }

    @Override
    public int deleteToken(TokenBean tokenBean) {
        int i = 0;
        try {    
            pst=con.prepareStatement("update token set active=? where token_id =? ");
            pst.setInt(1, 0);
            pst.setInt(2, tokenBean.getTokenId());
            i = pst.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(TokenDaoImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
    return i;
    }

    @Override
    public ResultSet getAllTokens() {
        ResultSet rst = null;
        try {
            pst=con.prepareStatement("select * from token where active = ?");
            pst.setInt(1, 1);
            rst = pst.executeQuery();
            
        } catch (SQLException ex) {
            Logger.getLogger(TokenDaoImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
        return rst;
    }

    @Override
    public TokenBean getTokenById(Integer tokenId) {
        TokenBean tokenBean = new TokenBean();
        try {    
            pst=con.prepareStatement("select * from token where token_id = ?");
            pst.setInt(1, tokenId);
            rst=pst.executeQuery();
            while(rst.next())
            {
              tokenBean.setTokenId(rst.getInt("token_id"));
              tokenBean.setTokenDiscount(rst.getDouble("token_discount"));
              tokenBean.setCreatedBy(rst.getInt("created_by"));
              tokenBean.setCreatedDate(rst.getTimestamp("created_date"));
              tokenBean.setModifiedBy(rst.getInt("modified_by"));
              tokenBean.setModifiedDate(rst.getTimestamp("modified_date")); 
            }
        } catch (SQLException ex) {
            Logger.getLogger(TokenDaoImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
        return tokenBean;
    }

    public Integer getTokenId(Timestamp createdDate) {
        Integer tokenId = 0;
        try {
            pst=con.prepareStatement("select token_id from token where created_date = ?");
            pst.setTimestamp(1, createdDate);
            rst=pst.executeQuery();
            while(rst.next())
            {
                tokenId = rst.getInt("token_id");
            }
        } catch (SQLException ex) {
            Logger.getLogger(TokenDaoImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
        return tokenId;
    }
    
}