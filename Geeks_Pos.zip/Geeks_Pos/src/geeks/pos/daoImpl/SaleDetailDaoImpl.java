/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package geeks.pos.daoImpl;

import geeks.pos.beans.SaleDetailBean;
import geeks.pos.connection.SqlConnection;
import geeks.pos.dao.SaleDetailDao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Asmat
 */
public class SaleDetailDaoImpl implements SaleDetailDao{
    private static final Connection con = SqlConnection.makeConnection();
    private static PreparedStatement pst ;
    private static ResultSet rst ;
    @Override
    public int addSaleDetail(SaleDetailBean saleDetailBean) {
        int i = 0;
        try {
            pst=con.prepareStatement("insert into sale_detail(product_id,product_quantity,price,sale_id,created_by,created_date,modified_by,modified_date)values(?,?,?,?,?,?,?,?)");
            pst.setInt(1, saleDetailBean.getProductId().getProductId());
            pst.setString(2, saleDetailBean.getProductQuantity());
            pst.setDouble(3, saleDetailBean.getPrice());
            pst.setInt(4, saleDetailBean.getSaleId().getSaleId());
            pst.setInt(5,saleDetailBean.getCreatedBy());
            pst.setTimestamp(6,saleDetailBean.getCreatedDate());
            pst.setInt(7,saleDetailBean.getModifiedBy());
            pst.setTimestamp(8,saleDetailBean.getModifiedDate());
            i = pst.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(SaleDetailDaoImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    return i;
    }

    @Override
    public int updateSaleDetail(SaleDetailBean saleDetailBean) {
        int i = 0;
        try {
            pst=con.prepareStatement("update sale_detail set product_id=?,product_quantity=?,price=?,sale_id=?,modified_by=?,modified_date=? where sale_detail_id = ?");
            pst.setInt(1, saleDetailBean.getProductId().getProductId());
            pst.setString(2, saleDetailBean.getProductQuantity());
            pst.setDouble(3, saleDetailBean.getPrice());
            pst.setInt(4, saleDetailBean.getSaleId().getSaleId());
            pst.setInt(5,saleDetailBean.getModifiedBy());
            pst.setTimestamp(6,saleDetailBean.getModifiedDate());
            pst.setInt(7, saleDetailBean.getSaleDetailId());
            i = pst.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(SaleDetailDaoImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    return i;
    }

    @Override
    public int deleteSaleDetail(SaleDetailBean saleDetailBean) {
        int i = 0;
        try {    
            pst=con.prepareStatement("update sale_detail set active=? where sale_detail_id =? ");
            pst.setInt(1, 0);
            pst.setInt(2, saleDetailBean.getSaleDetailId());
            i = pst.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(SaleDetailDaoImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
    return i;
    }

    @Override
    public List<SaleDetailBean> getAllSaleDetails() {
        List <SaleDetailBean> list = new ArrayList();
        try {
            pst=con.prepareStatement("select * from sale_detail where active = ?");
            pst.setInt(1, 1);
            rst = pst.executeQuery();
            while(rst.next())
            {
              SaleDetailBean saleDetailBean = new SaleDetailBean();
              ProductDaoImpl productDaoImpl = new ProductDaoImpl();
              SaleDaoImpl saleDaoImpl = new SaleDaoImpl();
              saleDetailBean.setSaleDetailId(rst.getInt("sale_detail_id"));
              saleDetailBean.setProductId(productDaoImpl.getProductById(rst.getInt("product_id")));
              saleDetailBean.setProductQuantity(rst.getString("product_quantity"));
              saleDetailBean.setPrice(rst.getDouble("price"));
              saleDetailBean.setSaleId(saleDaoImpl.getSaleById(rst.getInt("sale_id")));
              saleDetailBean.setCreatedBy(rst.getInt("created_by"));
              saleDetailBean.setCreatedDate(rst.getTimestamp("created_date"));
              saleDetailBean.setModifiedBy(rst.getInt("modified_by"));
              saleDetailBean.setModifiedDate(rst.getTimestamp("modified_date"));
              list.add(saleDetailBean);
            }
        } catch (SQLException ex) {
            Logger.getLogger(SaleDetailDaoImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
        return list;
    }

    @Override
    public SaleDetailBean getSaleDetailById(Integer saleDetailId) {
        SaleDetailBean saleDetailBean = new SaleDetailBean();
        ProductDaoImpl productDaoImpl = new ProductDaoImpl();
        SaleDaoImpl saleDaoImpl = new SaleDaoImpl();
        try {    
            pst=con.prepareStatement("select * from sale_detail where sale_detail_id = ?");
            pst.setInt(1, saleDetailId);
            rst=pst.executeQuery();
            while(rst.next())
            {
              saleDetailBean.setSaleDetailId(rst.getInt("sale_detail_id"));
              saleDetailBean.setProductId(productDaoImpl.getProductById(rst.getInt("product_id")));
              saleDetailBean.setProductQuantity(rst.getString("product_quantity"));
              saleDetailBean.setPrice(rst.getDouble("price"));
              saleDetailBean.setSaleId(saleDaoImpl.getSaleById(rst.getInt("sale_id")));
              saleDetailBean.setCreatedBy(rst.getInt("created_by"));
              saleDetailBean.setCreatedDate(rst.getTimestamp("created_date"));
              saleDetailBean.setModifiedBy(rst.getInt("modified_by"));
              saleDetailBean.setModifiedDate(rst.getTimestamp("modified_date"));
              
            }
        } catch (SQLException ex) {
            Logger.getLogger(SaleDetailDaoImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
        return saleDetailBean;
    }
    
}
