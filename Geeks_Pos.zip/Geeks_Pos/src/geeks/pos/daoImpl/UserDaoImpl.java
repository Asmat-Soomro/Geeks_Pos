/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package geeks.pos.daoImpl;

import geeks.pos.beans.UserBean;
import geeks.pos.connection.SqlConnection;
import geeks.pos.dao.UserDao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Asmat
 */
public class UserDaoImpl implements UserDao {
	private static UserBean userbean = new UserBean();
        private static final Connection con = SqlConnection.makeConnection();
        private static PreparedStatement pst ;
        private static ResultSet rst ;

        public UserBean login(String userName, String password) {
            UserBean userbean = null;
            try {
		pst = con.prepareStatement("Select user_id,user_name,password from user where user_name =? and password =? and active =?");
		pst.setString(1,userName);
		pst.setString(2,password);
                pst.setInt(3,1);
		rst = pst.executeQuery();
		while(rst.next()) {
			userbean = new UserBean();
			userbean.setUsername(rst.getString("user_name"));
			userbean.setPassword(rst.getString("password"));
                        userbean.setCreatedBy(rst.getInt("user_id"));
                        userbean.setModifiedBy(rst.getInt("user_id"));
			}
            }
	catch (SQLException e) {
	}
	return userbean;
	}
        
        public int createUser(UserBean userbean) {
        int i = 0;
        try {
        
		pst = con.prepareStatement("INSERT INTO USER(user_name,password,email,contact,gender,salary,security_question,security_answer,address,name,nic,user_type_id,user_code,comments,dob,doj,created_date,modified_date,created_by,modified_by) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)  ");
		pst.setString(1,userbean.getUsername());
		pst.setString(2,userbean.getPassword());
                pst.setString(3,userbean.getEmail());
                pst.setString(4,userbean.getContact());
                pst.setString(5,userbean.getGender());
                pst.setInt(6,userbean.getSalary());
                pst.setString(7,userbean.getSecurityQuestion());
                pst.setString(8,userbean.getSecurityAnswer());
                pst.setString(9,userbean.getAddress());
                pst.setString(10,userbean.getName());
                pst.setString(11,userbean.getNic());
                pst.setInt(12,userbean.getUserTypeId());
                pst.setString(13,userbean.getUserCode());
                pst.setString(14,userbean.getComment());
                pst.setTimestamp(15, userbean.getDob());
                pst.setTimestamp(16, userbean.getDoj());
                pst.setTimestamp(17, userbean.getCreatedDate());
                pst.setTimestamp(18, userbean.getModifiedDate());
                pst.setInt(19, userbean.getCreatedBy());
                pst.setInt(20, userbean.getModifiedBy());
		i = pst.executeUpdate();
                }
	catch (SQLException e) {
	}
        return i; 
    }

    @Override
    public ResultSet getAllUserRecords() {
        
            try {
        
                pst = con.prepareStatement("select * from user where active = ?");
                pst.setInt(1, 1);
                rst=pst.executeQuery();
                
            } catch (SQLException ex) {
                Logger.getLogger(UserDaoImpl.class.getName()).log(Level.SEVERE, null, ex);
            }
    return rst;
    }

    @Override
    public int updateUser(UserBean userbean, int mainId) {
            int i =0;
            try {
                pst=con.prepareStatement("update user set user_name=?, password=?, email=?, contact=?, gender=?, salary=?, security_question=? ,security_answer=?, address=?, name=?, nic=?, user_type_id=?, user_code=?, comments=?, dob=?, doj=?, modified_by=?, modified_date=? where user_id =?");
                pst.setString(1, userbean.getUsername());
                pst.setString(2, userbean.getPassword());
                pst.setString(3, userbean.getEmail());
                pst.setString(4, userbean.getContact());
                pst.setString(5, userbean.getGender());
                pst.setInt(6, userbean.getSalary());
                pst.setString(7, userbean.getSecurityQuestion());
                pst.setString(8, userbean.getSecurityAnswer());
                pst.setString(9, userbean.getAddress());
                pst.setString(10, userbean.getName());
                pst.setString(11, userbean.getNic());
                pst.setInt(12, userbean.getUserTypeId());
                pst.setString(13, userbean.getUserCode());
                pst.setString(14, userbean.getComment());
                pst.setTimestamp(15, userbean.getDob());
                pst.setTimestamp(16, userbean.getDoj());
                pst.setInt(17, userbean.getModifiedBy());
                pst.setTimestamp(18, userbean.getModifiedDate());
                pst.setInt(19, mainId);
                i=pst.executeUpdate();
                        
            } catch (SQLException ex) {
                Logger.getLogger(UserDaoImpl.class.getName()).log(Level.SEVERE, null, ex);
            }
     return i;
    }
    @Override
    public int deleteUser(String username) {
        int i =0;
            try {
                pst=con.prepareStatement("update user set active=? where user_name =? ");
                pst.setInt(1, 0);
                pst.setString(2, username);
                i=pst.executeUpdate();
            } catch (SQLException ex) {
                Logger.getLogger(UserDaoImpl.class.getName()).log(Level.SEVERE, null, ex);
            }
    return i;
    }

    public UserBean getSelectedRecord(int mainId) {

            try {
                pst=con.prepareStatement("select * from user where user_id = ?");
                pst.setInt(1, mainId);
                rst=pst.executeQuery();
                
                while(rst.next()){
                    userbean.setUsername(rst.getString("user_name"));
                    userbean.setPassword(rst.getString("password"));
                    userbean.setEmail(rst.getString("email"));
                    userbean.setContact(rst.getString("contact"));
                    userbean.setGender(rst.getString("gender"));
                    userbean.setDob(rst.getTimestamp("dob"));
                    userbean.setSalary(rst.getInt("salary"));
                    userbean.setSecurityQuestion(rst.getString("security_question"));
                    userbean.setSecurityAnswer(rst.getString("security_answer"));
                    userbean.setAddress(rst.getString("address"));
                    userbean.setName(rst.getString("name"));
                    userbean.setDoj(rst.getTimestamp("doj"));
                    userbean.setNic(rst.getString("nic"));
                    userbean.setUserTypeId(rst.getInt("user_type_id"));
                    userbean.setUserCode(rst.getString("user_code"));
                    userbean.setComment(rst.getString("comments"));
                }
            
            } catch (SQLException ex) {
                Logger.getLogger(UserDaoImpl.class.getName()).log(Level.SEVERE, null, ex);
            }
            return userbean;
    }

    @Override
    public int getId(String username) {
        int mainId=0;
            try {
                pst=con.prepareStatement("select user_id from user where user_name =?");
                pst.setString(1, username);
                rst=pst.executeQuery();
                while(rst.next())
                {
                   mainId = rst.getInt("user_id");
                }
            } catch (SQLException ex) {
                Logger.getLogger(UserDaoImpl.class.getName()).log(Level.SEVERE, null, ex);
            }
        return mainId;
    }

    public boolean checkUserName(String text) {
        boolean b = false;
            try {
                pst=con.prepareStatement("select user_name from user where user_name=?");
                pst.setString(1, text);
                rst=pst.executeQuery();
                while(rst.next())
                {
                    b=true;
                }
            } catch (SQLException ex) {
                Logger.getLogger(UserDaoImpl.class.getName()).log(Level.SEVERE, null, ex);
            }
            return b;
    }

    @Override
    public String getUserName(Integer id) {
        String mainUserName="";
            try {
                pst=con.prepareStatement("select user_name from user where user_id =?");
                pst.setInt(1, id);
                rst=pst.executeQuery();
                while(rst.next())
                {
                   mainUserName = rst.getString("user_name");
                }
            } catch (SQLException ex) {
                Logger.getLogger(UserDaoImpl.class.getName()).log(Level.SEVERE, null, ex);
            }
        return mainUserName;
    }
    
    
}