/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package geeks.pos.daoImpl;

import geeks.pos.beans.UserPermissionBean;
import geeks.pos.connection.SqlConnection;
import geeks.pos.dao.UserPermissionDao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Asmat
 */
public class UserPermissionDaoImpl implements UserPermissionDao{
    private static final Connection con = SqlConnection.makeConnection();
    private static PreparedStatement pst ;
    private static ResultSet rst ;
    @Override
    public ResultSet getAllUserAssignedPermissions(UserPermissionBean userPermissionBean) {
        try {
            pst=con.prepareStatement("SELECT * FROM permission WHERE permission_id IN (SELECT permission_id FROM user_permission WHERE user_id = ?)");
            pst.setInt(1, userPermissionBean.getUserId());
            rst=pst.executeQuery();
        } catch (SQLException ex) {
            Logger.getLogger(UserPermissionDaoImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
        return rst;
    }

    @Override
    public ResultSet getAllUserUnAssignedPermissions(UserPermissionBean userPermissionBean) {
        try {
            pst=con.prepareStatement("SELECT * FROM permission WHERE permission_id NOT IN (SELECT permission_id FROM user_permission WHERE user_id = ?)");
            pst.setInt(1, userPermissionBean.getUserId());
            rst=pst.executeQuery();
        } catch (SQLException ex) {
            Logger.getLogger(UserPermissionDaoImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
        return rst;
    }
    
}
