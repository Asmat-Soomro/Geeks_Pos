/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package geeks.pos.daoImpl;

import geeks.pos.beans.ProductBean;
import geeks.pos.connection.SqlConnection;
import geeks.pos.dao.ProductDao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Asmat
 */
public class ProductDaoImpl implements ProductDao{
    private static final Connection con = SqlConnection.makeConnection();
    private static PreparedStatement pst ;
    private static ResultSet rst ;
    @Override
    public int addProduct(ProductBean productBean) {
        
        int i = 0;
        try {
            pst=con.prepareStatement("insert into product(product_name,isbn,manufactory_date,expiry_date,bar_code,retail_price,sale_price,category_id,company_id,stock,warranty,size_id,comments,created_by,created_date,modified_by,modified_date)values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
            pst.setString(1,productBean.getProductName());
            pst.setString(2,productBean.getIsbn());
            pst.setTimestamp(3,productBean.getManufacturingDate());
            pst.setTimestamp(4,productBean.getExpiryDate());
            pst.setString(5,productBean.getBarCode());
            pst.setDouble(6, productBean.getRetailPrice());
            pst.setDouble(7, productBean.getSalePrice());
            pst.setInt(8, productBean.getCategoryId().getCategoryId());
            System.out.println(productBean.getCompany().getCompanyId());
            pst.setInt(9, productBean.getCompany().getCompanyId());
            pst.setInt(10, productBean.getStock());
            pst.setString(11, productBean.getWarranty());
            pst.setInt(12, productBean.getSizeId().getSizeId());
            pst.setString(13, productBean.getComments());
            pst.setInt(14,productBean.getCreatedBy());
            pst.setTimestamp(15,productBean.getCreatedDate());
            pst.setInt(16,productBean.getModifiedBy());
            pst.setTimestamp(17,productBean.getModifiedDate());
            i = pst.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(ProductDaoImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    return i;

    }

    @Override
    public int updateProduct(ProductBean productBean) {
        
        
        int i =0;
        try {
            pst=con.prepareStatement("update product set product_name=?,isbn=?,maufactory_date=?,expiry_date=?,bar_code=?,retail_price=?,sale_price=?,category_id=?,company_id=?,stock=?,warranty=?,size_id=?,comments=?, modified_by=?, modified_date=? where product_id =?");
            pst.setString(1,productBean.getProductName());
            pst.setString(2,productBean.getIsbn());
            pst.setTimestamp(3,productBean.getManufacturingDate());
            pst.setTimestamp(4,productBean.getExpiryDate());
            pst.setString(5,productBean.getBarCode());
            pst.setDouble(6, productBean.getRetailPrice());
            pst.setDouble(7, productBean.getSalePrice());
            pst.setInt(8, productBean.getCategoryId().getCategoryId());
            pst.setInt(9, productBean.getCompany().getCompanyId());
            pst.setInt(10, productBean.getStock());
            pst.setString(11, productBean.getWarranty());
            pst.setInt(12, productBean.getSizeId().getSizeId());
            pst.setString(13, productBean.getComments());
            pst.setInt(14,productBean.getModifiedBy());
            pst.setTimestamp(15,productBean.getModifiedDate());
            pst.setInt(16, productBean.getProductId());
            i = pst.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(ProductDaoImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
    return i;
    
    }

    @Override
    public int deleteProduct(ProductBean productBean) {
        int i = 0;
        try {    
            pst=con.prepareStatement("update product set active=? where product_id =? ");
            pst.setInt(1, 0);
            pst.setInt(2, productBean.getProductId());
            i = pst.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(ProductDaoImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
    return i;
    }

    @Override
    public List<ProductBean> getAllProducts() {
        
        List <ProductBean> list = new ArrayList();
        try {
            pst=con.prepareStatement("select * from product where active = ?");
            pst.setInt(1, 1);
            rst = pst.executeQuery();
            while(rst.next())
            {
                ProductBean productBean = new ProductBean();
                CategoryDaoImpl categoryDaoImpl = new CategoryDaoImpl();
                CompanyDaoImpl companyDaoImpl = new CompanyDaoImpl();
                SizeDaoImpl sizeDaoImpl = new SizeDaoImpl();
                productBean.setProductId(rst.getInt("product_id"));
                productBean.setProductName(rst.getString("product_name"));
                productBean.setIsbn(rst.getString("isbn"));
                productBean.setManufacturingDate(rst.getTimestamp("manufactory_date"));
                productBean.setExpiryDate(rst.getTimestamp("expiry_date"));
                productBean.setBarCode(rst.getString("bar_code"));
                productBean.setRetailPrice(rst.getDouble("retail_price"));
                productBean.setSalePrice(rst.getDouble("sale_price"));
                productBean.setCategoryId(categoryDaoImpl.getCategoryById(rst.getInt("category_id")));
                productBean.setCompany(companyDaoImpl.getCompanyById(rst.getInt("company_id")));
                productBean.setStock(rst.getInt("stock"));
                productBean.setWarranty(rst.getString("warranty"));
                productBean.setSizeId(sizeDaoImpl.getSizeById(rst.getInt("size_id")));
                productBean.setComments(rst.getString("comments"));
                productBean.setModifiedBy(rst.getInt("modified_by"));
                productBean.setModifiedDate(rst.getTimestamp("modified_date"));
              
              list.add(productBean);
            }
        } catch (SQLException ex) {
            Logger.getLogger(ProductDaoImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
        return list;
    
    }

    @Override
    public ProductBean getProductById(Integer ProductId) {
        ProductBean productBean = new ProductBean();
        CategoryDaoImpl categoryDaoImpl = new CategoryDaoImpl();
        CompanyDaoImpl companyDaoImpl = new CompanyDaoImpl();
        SizeDaoImpl sizeDaoImpl = new SizeDaoImpl();
        try {    
            pst=con.prepareStatement("select * from category where category_id = ?");
            pst.setInt(1, ProductId);
            rst=pst.executeQuery();
            while(rst.next())
            {
                productBean.setProductId(rst.getInt("product_id"));
                productBean.setProductName(rst.getString("product_name"));
                productBean.setIsbn(rst.getString("isbn"));
                productBean.setManufacturingDate(rst.getTimestamp("manufactory_date"));
                productBean.setExpiryDate(rst.getTimestamp("expiry_date"));
                productBean.setBarCode(rst.getString("bar_code"));
                productBean.setRetailPrice(rst.getDouble("retail_price"));
                productBean.setSalePrice(rst.getDouble("sale_price"));
                productBean.setCategoryId(categoryDaoImpl.getCategoryById(rst.getInt("category_id")));
                productBean.setCompany(companyDaoImpl.getCompanyById(rst.getInt("company_id")));
                productBean.setStock(rst.getInt("stock"));
                productBean.setWarranty(rst.getString("warranty"));
                productBean.setSizeId(sizeDaoImpl.getSizeById(rst.getInt("size_id")));
                productBean.setComments(rst.getString("comments"));
                productBean.setModifiedBy(rst.getInt("modified_by"));
                productBean.setModifiedDate(rst.getTimestamp("modified_date"));
            }
        } catch (SQLException ex) {
            Logger.getLogger(ProductDaoImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
        return productBean;
    }
    
}
