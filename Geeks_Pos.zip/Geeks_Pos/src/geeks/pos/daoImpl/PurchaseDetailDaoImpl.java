/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package geeks.pos.daoImpl;

import geeks.pos.beans.PurchaseDetailBean;
import geeks.pos.connection.SqlConnection;
import geeks.pos.dao.PurchaseDetailDao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Asmat
 */
public class PurchaseDetailDaoImpl implements PurchaseDetailDao{
    private static final Connection con = SqlConnection.makeConnection();
    private static PreparedStatement pst ;
    private static ResultSet rst ; 
    @Override
    public int addPurchaseDetail(PurchaseDetailBean purchaseDetailBean) {
        int i = 0;
        try {
            pst=con.prepareStatement("insert into purchase_detail(product_id,quantity,price,purchase_date,purchase_type,created_by,created_date,modified_by,modified_date)values(?,?,?,?,?,?,?,?,?)");
            pst.setInt(1, purchaseDetailBean.getProductId().getProductId());
            pst.setString(2, purchaseDetailBean.getQuantity());
            pst.setDouble(3, purchaseDetailBean.getPrice());
            pst.setTimestamp(4,purchaseDetailBean.getPurchaseDate());
            pst.setString(5, purchaseDetailBean.getPurchaseType());
            pst.setInt(6,purchaseDetailBean.getCreatedBy());
            pst.setTimestamp(7,purchaseDetailBean.getCreatedDate());
            pst.setInt(8,purchaseDetailBean.getModifiedBy());
            pst.setTimestamp(9,purchaseDetailBean.getModifiedDate());
            i = pst.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(PurchaseDetailDaoImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
    return i;
    }

    @Override
    public int updatePurchaseDetail(PurchaseDetailBean purchaseDetailBean) {
         int i = 0;
        try {
            pst=con.prepareStatement("update purchase_detail set product_id=?, quantity=?, price=?, purchase_date=?, purchase_type=?,  modified_by=?, modified_date=? where purchase_detail_id=?");
            pst.setInt(1, purchaseDetailBean.getProductId().getProductId());
            pst.setString(2, purchaseDetailBean.getQuantity());
            pst.setDouble(3, purchaseDetailBean.getPrice());
            pst.setTimestamp(4,purchaseDetailBean.getPurchaseDate());
            pst.setString(5, purchaseDetailBean.getPurchaseType());
            pst.setInt(6,purchaseDetailBean.getModifiedBy());
            pst.setTimestamp(7,purchaseDetailBean.getModifiedDate());
            pst.setInt(8, purchaseDetailBean.getPurchaseDetailId());
            i = pst.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(PurchaseDetailDaoImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
    return i;
    }

    @Override
    public int deletePurchaseDetail(PurchaseDetailBean purchaseDetailBean) {
        int i = 0;
        try {    
            pst=con.prepareStatement("update purchase_detail set active=? where purchase_detail_id =? ");
            pst.setInt(1, 0);
            pst.setInt(2, purchaseDetailBean.getPurchaseDetailId());
            i = pst.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(PurchaseDetailDaoImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
    return i;
    }

    @Override
    public List<PurchaseDetailBean> getAllPurchaseDetails() {
        List <PurchaseDetailBean> list = new ArrayList();
        try {
            pst=con.prepareStatement("select * from purchase_detail where active = ?");
            pst.setInt(1, 1);
            rst = pst.executeQuery();
            while(rst.next())
            {
              PurchaseDetailBean purchaseDetailBean = new PurchaseDetailBean();
              ProductDaoImpl productDaoImpl = new ProductDaoImpl();
              purchaseDetailBean.setPurchaseDetailId(rst.getInt("purchase_detail_id"));
              purchaseDetailBean.setProductId(productDaoImpl.getProductById(rst.getInt("product_id")));
              purchaseDetailBean.setQuantity(rst.getString("quantity"));
              purchaseDetailBean.setPrice(rst.getDouble("price"));
              purchaseDetailBean.setPurchaseDate(rst.getTimestamp("purchase_date"));
              purchaseDetailBean.setPurchaseType(rst.getString("purchase_type"));
              purchaseDetailBean.setCreatedBy(rst.getInt("created_by"));
              purchaseDetailBean.setCreatedDate(rst.getTimestamp("created_date"));
              purchaseDetailBean.setModifiedBy(rst.getInt("modified_by"));
              purchaseDetailBean.setModifiedDate(rst.getTimestamp("modified_date"));
              list.add(purchaseDetailBean);
            }
        } catch (SQLException ex) {
            Logger.getLogger(PurchaseDetailDaoImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
        return list;
    }

    @Override
    public PurchaseDetailBean getPurchaseDetailById(Integer purchaseDetailId) {
        PurchaseDetailBean purchaseDetailBean = new PurchaseDetailBean();
        ProductDaoImpl productDaoImpl = new ProductDaoImpl();
        try {    
            pst=con.prepareStatement("select * from purchase_detail where purchase_detail_id = ?");
            pst.setInt(1, purchaseDetailId);
            rst=pst.executeQuery();
            while(rst.next())
            {
              purchaseDetailBean.setPurchaseDetailId(rst.getInt("purchase_detail_id"));
              purchaseDetailBean.setProductId(productDaoImpl.getProductById(rst.getInt("product_id")));
              purchaseDetailBean.setQuantity(rst.getString("quantity"));
              purchaseDetailBean.setPrice(rst.getDouble("price"));
              purchaseDetailBean.setPurchaseDate(rst.getTimestamp("purchase_date"));
              purchaseDetailBean.setPurchaseType(rst.getString("purchase_type"));
              purchaseDetailBean.setCreatedBy(rst.getInt("created_by"));
              purchaseDetailBean.setCreatedDate(rst.getTimestamp("created_date"));
              purchaseDetailBean.setModifiedBy(rst.getInt("modified_by"));
              purchaseDetailBean.setModifiedDate(rst.getTimestamp("modified_date"));
            }
        } catch (SQLException ex) {
            Logger.getLogger(PurchaseDetailDaoImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
        return purchaseDetailBean;
    }
    
}
