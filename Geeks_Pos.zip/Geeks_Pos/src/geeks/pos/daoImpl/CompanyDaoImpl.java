/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package geeks.pos.daoImpl;

import geeks.pos.beans.CompanyBean;
import geeks.pos.connection.SqlConnection;
import geeks.pos.dao.CompanyDao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
/**
 *
 * @author Asmat
 */
public class CompanyDaoImpl implements CompanyDao{
    private static final Connection con = SqlConnection.makeConnection();
    private static PreparedStatement pst ;
    private static ResultSet rst ;
    @Override
    public int addCompany(CompanyBean companyBean){
    int i = 0;
        try {
            pst=con.prepareStatement("insert into company(company_name,location,contact_person,contact_no,created_by,created_date,modified_by,modified_date)values(?,?,?,?,?,?,?,?)");
            pst.setString(1,companyBean.getCompanyName());
            pst.setString(2,companyBean.getLocation());
            pst.setString(3,companyBean.getContactPerson());
            pst.setString(4,companyBean.getContactNo());
            pst.setInt(5, companyBean.getCreatedBy());
            pst.setTimestamp(6, companyBean.getCreatedDate());
            pst.setInt(7, companyBean.getModifiedBy());
            pst.setTimestamp(8, companyBean.getModifiedDate());
            i = pst.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(CompanyDaoImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
    return i;
    }

    @Override
    public int updateCompany(CompanyBean companyBean) {
        int i =0;
        try {
            pst=con.prepareStatement("update company set company_name=?, location=?, contact_person=?, contact_no=?, modified_by=?, modified_date=? where company_id =?");
            pst.setString(1, companyBean.getCompanyName());
            pst.setString(2,companyBean.getLocation());
            pst.setString(3,companyBean.getContactPerson());
            pst.setString(4,companyBean.getContactNo());
            pst.setInt(5, companyBean.getModifiedBy());
            pst.setTimestamp(6, companyBean.getModifiedDate());
            pst.setInt(7, companyBean.getCompanyId());
            i = pst.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(CompanyDaoImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
    return i;
    }

    @Override
    public int deleteCompany(CompanyBean companyBean) {        
        int i = 0;
        try {    
            pst=con.prepareStatement("update company set active=? where company_id =? ");
            pst.setInt(1, 0);
            pst.setInt(2, companyBean.getCompanyId());
            i = pst.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(CompanyDaoImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
    return i;
    }

    @Override
    public ResultSet getAllCompanies() {
        try {
            pst=con.prepareStatement("select * from company where active = ?");
            pst.setInt(1, 1);
            rst = pst.executeQuery();
        } catch (SQLException ex) {
            Logger.getLogger(CompanyDaoImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
        return rst;
    }

    @Override
    public CompanyBean getCompanyById(Integer CompanyId) {
        CompanyBean companyBean = null;
        try {    
            pst=con.prepareStatement("select * from company where company_id = ?");
            pst.setInt(1, CompanyId);
            rst=pst.executeQuery();
            while(rst.next())
            {
              companyBean = new CompanyBean();
              companyBean.setCompanyId(rst.getInt("company_id"));
              companyBean.setCompanyName(rst.getString("company_name"));
              companyBean.setLocation(rst.getString("location"));
              companyBean.setContactPerson("contact_person");
              companyBean.setContactNo("contact_no");
              companyBean.setCreatedBy(rst.getInt("created_by"));
              companyBean.setCreatedDate(rst.getTimestamp("created_date"));
              companyBean.setModifiedBy(rst.getInt("modified_by"));
              companyBean.setModifiedDate(rst.getTimestamp("modified_date"));
            }
        } catch (SQLException ex) {
            Logger.getLogger(CompanyDaoImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
        return companyBean;
    }

    public Integer getCompanyId(String companyName) {
        Integer companyId = 0;
        try {
            pst=con.prepareStatement("select company_id from company where company_name = ?");
            pst.setString(1, companyName);
            rst=pst.executeQuery();
            while(rst.next())
            {
                companyId = rst.getInt("company_id");
            }    
                } catch (SQLException ex) {
            Logger.getLogger(CompanyDaoImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
        return companyId;   
    }
}