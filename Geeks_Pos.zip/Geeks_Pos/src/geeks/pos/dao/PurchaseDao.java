/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package geeks.pos.dao;

import geeks.pos.beans.PurchaseBean;
import java.util.List;

/**
 *
 * @author Asmat
 */
public interface PurchaseDao {
    public int addPurchase(PurchaseBean purchaseBean);
    public int updatePurchase(PurchaseBean purchaseBean);
    public int deletePurchase(PurchaseBean purchaseBean);
    public List <PurchaseBean> getAllPurchases();
    PurchaseBean getPurchaseById (Integer purchaseId);
}
