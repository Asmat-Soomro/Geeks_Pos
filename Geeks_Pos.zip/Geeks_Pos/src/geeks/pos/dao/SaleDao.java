/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package geeks.pos.dao;

import geeks.pos.beans.SaleBean;
import java.util.List;

/**
 *
 * @author Asmat
 */
public interface SaleDao {
    public int addSale(SaleBean saleBean);
    public int updateSale(SaleBean saleBean);
    public int deleteSale(SaleBean saleBean);
    public List <SaleBean> getAllSales();
    SaleBean getSaleById (Integer saleId);
}
