/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package geeks.pos.dao;

import geeks.pos.beans.TokenBean;
import java.sql.ResultSet;

/**
 *
 * @author Asmat
 */
public interface TokenDao {
    public int addToken(TokenBean tokenBean);
    public int updateToken(TokenBean tokenBean);
    public int deleteToken(TokenBean tokenBean);
    public ResultSet getAllTokens();
    TokenBean getTokenById (Integer tokenId);
}
