/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package geeks.pos.dao;

import geeks.pos.beans.PurchaseDetailBean;
import java.util.List;

/**
 *
 * @author Asmat
 */
public interface PurchaseDetailDao {
    public int addPurchaseDetail(PurchaseDetailBean purchaseDetailBean);
    public int updatePurchaseDetail(PurchaseDetailBean purchaseDetailBean);
    public int deletePurchaseDetail(PurchaseDetailBean purchaseDetailBean);
    public List <PurchaseDetailBean> getAllPurchaseDetails();
    PurchaseDetailBean getPurchaseDetailById (Integer purchaseDetailId);
}
