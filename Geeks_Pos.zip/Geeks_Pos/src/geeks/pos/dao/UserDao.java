/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package geeks.pos.dao;

import geeks.pos.beans.Bean;
import geeks.pos.beans.UserBean;
import java.sql.ResultSet;

/**
 *
 * @author Asmat
 */
public interface UserDao {

    public UserBean login(String userName, String password);
    public int createUser (UserBean userbean);
    public int updateUser (UserBean userbean, int mainId);
    public int deleteUser (String username);
    public ResultSet getAllUserRecords();
    public UserBean getSelectedRecord(int mainId);
    public int getId(String username);
    public boolean checkUserName(String text);
    public String getUserName(Integer id);
}