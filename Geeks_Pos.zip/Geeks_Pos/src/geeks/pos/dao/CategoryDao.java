/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package geeks.pos.dao;

import geeks.pos.beans.CategoryBean;
import java.sql.ResultSet;
import java.util.List;

/**
 *
 * @author Asmat
 */
public interface CategoryDao {
    public int addCategory(CategoryBean categoryBean);
    public int updateCategory(CategoryBean categoryBean);
    public int deleteCategory(CategoryBean categoryBean);
    public ResultSet getAllCategories();
    public CategoryBean getCategoryById (Integer CategoryId);
    public List<CategoryBean> getAllParentCategories();
    
    
}
