/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package geeks.pos.dao;

import geeks.pos.beans.UserPermissionBean;
import java.sql.ResultSet;

/**
 *
 * @author Asmat
 */
public interface UserPermissionDao {
    
    public ResultSet getAllUserAssignedPermissions(UserPermissionBean userPermissionBean);
    public ResultSet getAllUserUnAssignedPermissions(UserPermissionBean userPermissionBean);
}