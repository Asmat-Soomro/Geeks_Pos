/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package geeks.pos.dao;

import geeks.pos.beans.SizeBean;
import java.sql.ResultSet;
import java.util.List;

/**
 *
 * @author Asmat
 */
public interface SizeDao {
    public int addSize(SizeBean sizeBean);
    public int updateSize(SizeBean sizeBean);
    public int deleteSize(SizeBean sizeBean);
    public ResultSet getAllSizes();
    SizeBean getSizeById (Integer sizeId);
}
