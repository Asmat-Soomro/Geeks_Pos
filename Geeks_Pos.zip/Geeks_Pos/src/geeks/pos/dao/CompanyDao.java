/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package geeks.pos.dao;

import geeks.pos.beans.CompanyBean;
import java.sql.ResultSet;

/**
 *
 * @author Asmat
 */
public interface CompanyDao {
    public int addCompany(CompanyBean companyBean);
    public int updateCompany(CompanyBean companyBean);
    public int deleteCompany(CompanyBean companyBean);
    public ResultSet getAllCompanies();
    CompanyBean getCompanyById (Integer CompanyId);
}
