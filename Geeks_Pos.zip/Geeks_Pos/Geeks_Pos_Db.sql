/*
SQLyog Ultimate v11.11 (64 bit)
MySQL - 5.5.5-10.1.10-MariaDB : Database - geeks_pos_db
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`geeks_pos_db` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `geeks_pos_db`;

/*Table structure for table `category` */

DROP TABLE IF EXISTS `category`;

CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_category` int(11) DEFAULT NULL,
  `category_name` varchar(255) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `modified_date` datetime DEFAULT NULL,
  `active` int(1) DEFAULT '1',
  PRIMARY KEY (`category_id`),
  KEY `parent_category_fk` (`parent_category`),
  CONSTRAINT `parent_category_fk` FOREIGN KEY (`parent_category`) REFERENCES `category` (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=latin1;

/*Data for the table `category` */

insert  into `category`(`category_id`,`parent_category`,`category_name`,`created_by`,`created_date`,`modified_by`,`modified_date`,`active`) values (18,NULL,'Garments',1,'2018-11-11 20:57:54',1,'2018-11-13 08:28:54',1),(19,18,'Women',1,'2018-11-11 20:58:16',1,'2018-11-13 08:33:29',1),(20,18,'Kids',6,'2018-11-11 21:00:52',3,'2018-11-11 21:01:45',1),(21,18,'Men',3,'2018-11-11 21:09:41',3,'2018-11-11 21:09:41',1),(22,NULL,'Hardware',1,'2018-11-11 21:21:32',1,'2018-11-12 15:38:24',1),(23,NULL,'Null',1,'2018-11-11 21:22:19',1,'2018-11-13 08:30:38',1),(24,NULL,'Softwares',1,'2018-11-12 15:39:11',1,'2018-11-12 15:54:37',1),(25,NULL,'Shampo',1,'2018-11-13 08:29:03',1,'2018-11-13 08:29:03',1),(26,22,'Keyboard',1,'2018-11-13 08:33:38',1,'2018-11-13 08:33:38',1),(27,24,'Windows',1,'2018-11-13 08:33:54',1,'2018-11-13 08:33:54',1),(28,25,'BioAmla',1,'2018-11-13 08:34:06',1,'2018-11-13 08:34:06',1);

/*Table structure for table `company` */

DROP TABLE IF EXISTS `company`;

CREATE TABLE `company` (
  `company_id` int(11) NOT NULL AUTO_INCREMENT,
  `company_name` varchar(255) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `contact_person` varchar(255) DEFAULT NULL,
  `contact_no` varchar(255) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `modified_date` datetime DEFAULT NULL,
  `active` int(1) DEFAULT '1',
  PRIMARY KEY (`company_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

/*Data for the table `company` */

insert  into `company`(`company_id`,`company_name`,`location`,`contact_person`,`contact_no`,`created_by`,`created_date`,`modified_by`,`modified_date`,`active`) values (1,'Asmat Company','Hyderabad','Asmat','03352022009',1,'2018-11-09 20:20:19',1,'2018-11-11 22:55:25',1),(2,'Surriya Textile Mill','Kotri','Zubair Ahmed','03003022009',1,'2018-11-11 22:56:07',1,'2018-11-11 22:56:07',1),(3,'Rafan','Karachi','Abdullah','12345',1,'2018-11-12 22:49:46',1,'2018-11-12 22:50:42',1),(4,'FFC','Naudero','Nil','789',1,'2018-11-12 22:50:10',1,'2018-11-12 22:51:17',1);

/*Table structure for table `company_category` */

DROP TABLE IF EXISTS `company_category`;

CREATE TABLE `company_category` (
  `company_id` int(11) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  KEY `category_id_fk` (`category_id`),
  KEY `company_id_fk` (`company_id`),
  CONSTRAINT `category_id_fk` FOREIGN KEY (`category_id`) REFERENCES `category` (`category_id`),
  CONSTRAINT `company_id_fk` FOREIGN KEY (`company_id`) REFERENCES `company` (`company_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `company_category` */

/*Table structure for table `permission` */

DROP TABLE IF EXISTS `permission`;

CREATE TABLE `permission` (
  `permission_id` int(11) NOT NULL AUTO_INCREMENT,
  `permission_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`permission_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

/*Data for the table `permission` */

insert  into `permission`(`permission_id`,`permission_name`) values (1,'view_user'),(2,'update_user'),(3,'add_user'),(4,'delete_user');

/*Table structure for table `product` */

DROP TABLE IF EXISTS `product`;

CREATE TABLE `product` (
  `product_id` int(11) NOT NULL AUTO_INCREMENT,
  `product_name` varchar(255) DEFAULT NULL,
  `isbn` varchar(255) DEFAULT NULL,
  `manufactory_date` date DEFAULT NULL,
  `expiry_date` date DEFAULT NULL,
  `bar_code` varchar(255) DEFAULT NULL,
  `retail_price` double(11,2) DEFAULT NULL,
  `sale_price` double(11,2) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `company_id` int(11) DEFAULT NULL,
  `stock` int(11) DEFAULT NULL,
  `warranty` varchar(255) DEFAULT NULL,
  `size_id` int(11) DEFAULT NULL,
  `comments` varchar(255) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `modified_date` datetime DEFAULT NULL,
  `active` int(1) DEFAULT '1',
  PRIMARY KEY (`product_id`),
  KEY `product_category_id_fk` (`category_id`),
  KEY `product_company_id_fk` (`company_id`),
  CONSTRAINT `product_category_id_fk` FOREIGN KEY (`category_id`) REFERENCES `category` (`category_id`),
  CONSTRAINT `product_company_id_fk` FOREIGN KEY (`company_id`) REFERENCES `company` (`company_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `product` */

/*Table structure for table `puchase` */

DROP TABLE IF EXISTS `puchase`;

CREATE TABLE `puchase` (
  `purchase_id` int(11) DEFAULT NULL,
  `purchase_date` date DEFAULT NULL,
  `company_id` int(11) DEFAULT NULL,
  `purchase_number` int(11) DEFAULT NULL,
  `discount_type` varchar(255) DEFAULT NULL,
  `value` varchar(255) DEFAULT NULL,
  `comments` varchar(255) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `modified_date` datetime DEFAULT NULL,
  KEY `purchase_company_id_fk` (`company_id`),
  CONSTRAINT `purchase_company_id_fk` FOREIGN KEY (`company_id`) REFERENCES `company` (`company_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `puchase` */

/*Table structure for table `purchase_detail` */

DROP TABLE IF EXISTS `purchase_detail`;

CREATE TABLE `purchase_detail` (
  `purchase_detail_id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) DEFAULT NULL,
  `quantity` varchar(255) DEFAULT NULL,
  `price` double(11,2) DEFAULT NULL,
  `purchase_date` datetime DEFAULT NULL,
  `puchase_type` varchar(255) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `modified_date` datetime DEFAULT NULL,
  PRIMARY KEY (`purchase_detail_id`),
  KEY `purchace_detail_product_id_fk` (`product_id`),
  CONSTRAINT `purchace_detail_product_id_fk` FOREIGN KEY (`product_id`) REFERENCES `product` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `purchase_detail` */

/*Table structure for table `sale` */

DROP TABLE IF EXISTS `sale`;

CREATE TABLE `sale` (
  `sale_id` int(11) NOT NULL AUTO_INCREMENT,
  `sale_date` datetime DEFAULT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `employee_id` int(11) DEFAULT NULL,
  `sale_number` int(11) DEFAULT NULL,
  `comments` varchar(255) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `ctreated_date` datetime DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `modified_date` datetime DEFAULT NULL,
  PRIMARY KEY (`sale_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `sale` */

/*Table structure for table `sale_detail` */

DROP TABLE IF EXISTS `sale_detail`;

CREATE TABLE `sale_detail` (
  `sale_detail_id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) DEFAULT NULL,
  `product_quantity` varchar(255) DEFAULT NULL,
  `price` double(11,2) DEFAULT NULL,
  `sale_id` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `modified_date` datetime DEFAULT NULL,
  PRIMARY KEY (`sale_detail_id`),
  KEY `sale_details_product_id_fk` (`product_id`),
  KEY `sale_details_sale_id_fk` (`sale_id`),
  CONSTRAINT `sale_details_product_id_fk` FOREIGN KEY (`product_id`) REFERENCES `product` (`product_id`),
  CONSTRAINT `sale_details_sale_id_fk` FOREIGN KEY (`sale_id`) REFERENCES `sale` (`sale_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `sale_detail` */

/*Table structure for table `size` */

DROP TABLE IF EXISTS `size`;

CREATE TABLE `size` (
  `size_id` int(11) NOT NULL AUTO_INCREMENT,
  `size` varchar(11) DEFAULT NULL,
  `pack` varchar(255) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `modified_date` datetime DEFAULT NULL,
  `active` int(1) DEFAULT '1',
  PRIMARY KEY (`size_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

/*Data for the table `size` */

insert  into `size`(`size_id`,`size`,`pack`,`created_by`,`created_date`,`modified_by`,`modified_date`,`active`) values (1,'10ml','Tetra Pack',1,'2018-11-11 10:56:50',1,'2018-11-11 23:16:29',1),(2,'100ml','Tin',6,'2018-11-11 11:00:02',1,'2018-11-11 23:37:37',1),(3,'500ml','Bottle',1,'2018-11-11 23:37:03',1,'2018-11-11 23:37:14',1);

/*Table structure for table `token` */

DROP TABLE IF EXISTS `token`;

CREATE TABLE `token` (
  `token_id` int(11) NOT NULL AUTO_INCREMENT,
  `token_name` varchar(255) DEFAULT NULL,
  `token_discount` double(11,2) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `modified_date` datetime DEFAULT NULL,
  `active` int(1) DEFAULT '1',
  PRIMARY KEY (`token_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

/*Data for the table `token` */

insert  into `token`(`token_id`,`token_name`,`token_discount`,`created_by`,`created_date`,`modified_by`,`modified_date`,`active`) values (1,'My Token',50.00,1,'2018-11-12 00:06:08',1,'2018-11-12 00:27:18',1),(2,'SpecialDiscount',90.00,1,'2018-11-12 00:28:35',1,'2018-11-12 00:28:44',1);

/*Table structure for table `user` */

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `contact` varchar(255) DEFAULT NULL,
  `gender` enum('Male','Female') DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `salary` int(11) DEFAULT NULL,
  `security_question` varchar(255) DEFAULT NULL,
  `security_answer` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `doj` date DEFAULT NULL,
  `nic` varchar(255) DEFAULT NULL,
  `user_type_id` int(11) DEFAULT NULL,
  `user_code` varchar(255) DEFAULT NULL,
  `comments` varchar(255) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `modified_date` datetime DEFAULT NULL,
  `active` int(1) DEFAULT '1',
  PRIMARY KEY (`user_id`),
  KEY `user_type_id_fk` (`user_type_id`),
  CONSTRAINT `user_type_id_fk` FOREIGN KEY (`user_type_id`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

/*Data for the table `user` */

insert  into `user`(`user_id`,`user_name`,`password`,`email`,`contact`,`gender`,`dob`,`salary`,`security_question`,`security_answer`,`address`,`name`,`doj`,`nic`,`user_type_id`,`user_code`,`comments`,`created_by`,`created_date`,`modified_by`,`modified_date`,`active`) values (1,'Asmat','123','Asmat@gmail.com','0335','Male','1997-07-05',890000,'What Is The Name Of Your Favourite Cousin?','Jani','Kotri','Asmatullah','2018-10-22','43402',2,'F16SW157','Good',0,'2018-10-21 01:22:18',1,'2018-10-22 12:38:51',1),(2,'Jawad','123','Jawad@gmail.com','0300','Male','1997-10-10',890000,'What Is The Name Of Your Favourite Movie?','PK','Resham Gali Larkana','Jawad Mangan','2018-10-21','434033',2,'F16SW44','Good',1,'2018-10-21 01:24:53',2,'2018-10-21 18:53:33',1),(3,'Amjad','123','Amjad@gmail.com','1234567','Male','1997-10-10',6785,'What Is The Name Of Your Favourite Teacher?','Mam Sandhiya','Nawabshah','Amjad Dahri','2018-10-21','67894523',1,'F16SW27','VIP',2,'2018-10-21 01:46:09',3,'2018-10-21 10:57:51',1),(4,'Shakoor','123','Shakoor@gmail.com','12234566778','Male','1997-10-10',50000,'What Is The Name Of Your Best Friend?','Ali','Google Kar Lo','Shakoor Sawand','2018-10-21','4340209876654',1,'F16SW12','V.Good',3,'2018-10-21 10:59:57',4,'2018-10-21 11:01:48',1),(5,'Umar','123','Umar@gmail.com','03000000000','Male','1998-10-22',700000,'In Which City You Were Born?','Thull','Jacobabad','Umar Pahore','2018-10-21','4567890123456',1,'81','Nill',4,'2018-10-21 11:05:39',4,'2018-10-21 11:05:39',1),(6,'Sadaquat','123','sadaquat@live.com','03375','Male','1990-09-07',400000,'What Is The Name Of Your Favourite Teacher?','Sir Shehzad','Ghotki','Sadaquat Ali Ruk','2018-10-09','123456',2,'123','123',1,'2018-10-21 17:54:12',6,'2018-10-24 09:22:48',1),(7,'Vinod','123','Vinod@gmail.com','123','Male','2018-10-01',40000,'What Is The Name Of Your Favourite Teacher?','Mam Hira','Tower Market','Vinood Bheel','2018-10-24','23456789',1,'61','Nil',6,'2018-10-24 09:53:47',6,'2018-10-24 09:53:47',1),(8,'Rashid','000','rashid@','12345678','Male','2018-10-01',66,'In Which City You Were Born?','Dadu','gharibabad','Rashid majeed','2018-10-02','123456789',1,'55','Asmat is a cute boy',1,'2018-10-25 17:57:12',1,'2018-10-25 17:57:47',1);

/*Table structure for table `user_permission` */

DROP TABLE IF EXISTS `user_permission`;

CREATE TABLE `user_permission` (
  `user_id` int(11) DEFAULT NULL,
  `permission_id` int(11) DEFAULT NULL,
  KEY `user_id` (`user_id`),
  KEY `permission_id` (`permission_id`),
  CONSTRAINT `user_permission_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`),
  CONSTRAINT `user_permission_ibfk_2` FOREIGN KEY (`permission_id`) REFERENCES `permission` (`permission_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `user_permission` */

/*Table structure for table `user_type` */

DROP TABLE IF EXISTS `user_type`;

CREATE TABLE `user_type` (
  `user_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_type` varchar(255) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `modified_date` datetime DEFAULT NULL,
  `active` int(1) DEFAULT '1',
  PRIMARY KEY (`user_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

/*Data for the table `user_type` */

insert  into `user_type`(`user_type_id`,`user_type`,`created_by`,`created_date`,`modified_by`,`modified_date`,`active`) values (1,'Employee',1,'2018-11-02 16:00:00',1,'2018-11-02 16:00:00',1),(2,'Customer',1,'2018-11-02 16:11:27',1,'2018-11-02 16:11:33',1);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
